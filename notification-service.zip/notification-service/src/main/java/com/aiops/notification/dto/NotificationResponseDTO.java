package com.aiops.notification.dto;

public class NotificationResponseDTO {

}
