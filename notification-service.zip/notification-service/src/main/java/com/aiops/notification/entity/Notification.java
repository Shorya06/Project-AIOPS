package com.aiops.notification.entity;

public class Notification {

}
