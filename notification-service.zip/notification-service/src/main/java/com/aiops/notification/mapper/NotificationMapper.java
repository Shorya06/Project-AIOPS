package com.aiops.notification.mapper;

public class NotificationMapper {

}
