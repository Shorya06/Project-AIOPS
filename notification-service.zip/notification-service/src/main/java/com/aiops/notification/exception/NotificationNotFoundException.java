package com.aiops.notification.exception;

public class NotificationNotFoundException {

}
