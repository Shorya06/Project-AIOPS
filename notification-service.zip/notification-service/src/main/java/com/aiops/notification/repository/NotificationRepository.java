package com.aiops.notification.repository;

public class NotificationRepository {

}
