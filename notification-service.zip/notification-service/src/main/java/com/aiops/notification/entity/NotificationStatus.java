package com.aiops.notification.entity;

public class NotificationStatus {

}
