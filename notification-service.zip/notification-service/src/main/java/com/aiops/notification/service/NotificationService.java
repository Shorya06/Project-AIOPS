package com.aiops.notification.service;

public class NotificationService {

}
